function updateChartA(){
    var d = new Date(); 
    d.setDate(d.getDate()-period+1); 
    var m=d.getMonth()+1; 
    $.ajax({
        url: "http://localhost:8080/info/period", 
        type: "GET", 
        data:{
            tag:tag,
            type:type,
            id:id,
            period:period,
            start:d.getFullYear()+'-'+m+'-'+d.getDate()
        },
        success:function(data){
            if(data.success == 0) {alert("nerwork error"); return;}
            var chart = echarts.init(document.getElementById('chartA'));
            var array1 = []
            var array2 = []
            for (var i = 0; i < data.detail.length; i++) {
                array1.push(data.detail[i].time)
                array2.push(data.detail[i].score)
            }
            chart.setOption({
                xAxis: {
                    type: 'category',
                    data: array1
                },
                yAxis: {
                    type: 'value'
                },
                series: [{
                    data: array2,
                    type: 'line'
                }]
            })
        },
        error: function(){
            alert("nerwork error")
        }
    });
}

function updateChartB(){
    $.ajax({
        url: "http://localhost:8080/info/detail", 
        type: "GET", 
        data:{
            tag:tag,
            type:type,
            id:id,
            period:period,
            time:nowtime
        },
        success:function(data){
            if(data.success == 0) {alert("nerwork error"); return;}
            var chart = echarts.init(document.getElementById('chartB'));
            var array1 = []
            var array2 = []
            for (var i = 0; i < data.detail.length; i++) {
                array1.push(data.detail[i].name)
                array2.push({value:data.detail[i].score, name:data.detail[i].name})
            }
            chart.setOption({
                tooltip : {
                    trigger: 'item',
                    formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                    orient: 'vertical',
                    left: 'left',
                    data: array1
                },
                series : [
                    {
                        name: '访问来源',
                        type: 'pie',
                        radius : '55%',
                        center: ['50%', '60%'],
                        data:array2,
                        itemStyle: {
                            emphasis: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            })
        },
        error: function(){
            alert("nerwork error")
        }
    });
}