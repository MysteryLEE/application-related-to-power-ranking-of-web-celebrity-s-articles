function reloadList(){
    $.ajax({ 
        url: "http://localhost:8080/info/list", 
        type: "GET", 
        data:{
            tag:tag,
            type:type,
            size:size,
            period:period
        },
        success: function(data){
            if(data.success == 0) {alert("nerwork error"); return;}
            var el = $('#list-body');
            if(type == 1)var string = "<tr><th class='table-rank'>排名</th><th class='table-name'>用户</th><th class='table-source'>平台</th><th class='table-score'>得分</th></tr>";
            else var string = "<tr><th class='table-rank'>排名</th><th class='table-title'>标题</th><th class='table-author'>作者</th><th class='table-time'>时间</th><th class='table-source'>平台</th><th class='table-score'>得分</th></tr>";
            for (var i = 0; i < data.list.length; i++) {
                if(type == 1){
                    string += "<tr><td>"+data.list[i].no+"</td>"
                    string += "<td><a href='detail.html?tag="+tag+"&type=1&id="+data.list[i].id+"&name="+encodeURI(encodeURI(data.list[i].name))+"&source="+data.list[i].source.join('')+"'>"+data.list[i].name+"</a></td>"
                    string += "<td><div class='am-btn-toolbar'><div class='am-btn-group am-btn-group-xs'>"
                    if(data.list[i].source.indexOf(1) != -1) string += "<button class='am-btn am-btn-default am-btn-xs am-text-danger'> 微博</button>";
                    else string += "<button class='am-btn am-btn-default am-btn-xs am-text-danger' disabled> 微博</button>";
                    if(data.list[i].source.indexOf(2) != -1) string += "<button class='am-btn am-btn-default am-btn-xs am-text-success'> 微信</button>";
                    else string += "<button class='am-btn am-btn-default am-btn-xs am-text-success' disabled> 微信</button>";
                    if(data.list[i].source.indexOf(3) != -1) string += "<button class='am-btn am-btn-default am-btn-xs am-text-secondary'> 知乎</button>";
                    else string += "<button class='am-btn am-btn-default am-btn-xs am-text-secondary' disabled> 知乎</button>";
                    string += "<td>"+data.list[i].score+"</td></tr>";
                }
                else{
                    string += "<tr><td>"+data.list[i].no+"</td>"
                    string += "<td><a href='detail.html?tag="+tag+"&type=2&id="+data.list[i].id+"&name="+encodeURI(encodeURI(data.list[i].title))+"&author="+encodeURI(encodeURI(data.list[i].author))+"&time="+data.list[i].time+"&source="+data.list[i].source.join('')+"'>"+data.list[i].title+"</a></td>"
                    string += "<td>"+data.list[i].author+"</td>"
                    string += "<td>"+data.list[i].time+"</td>"
                    string += "<td><div class='am-btn-toolbar'><div class='am-btn-group am-btn-group-xs'>"
                    if(data.list[i].source.indexOf(1) != -1) string += "<button class='am-btn am-btn-default am-btn-xs am-text-danger'> 微博</button>";
                    else string += "<button class='am-btn am-btn-default am-btn-xs am-text-danger' disabled> 微博</button>";
                    if(data.list[i].source.indexOf(2) != -1) string += "<button class='am-btn am-btn-default am-btn-xs am-text-success'> 微信</button>";
                    else string += "<button class='am-btn am-btn-default am-btn-xs am-text-success' disabled> 微信</button>";
                    if(data.list[i].source.indexOf(3) != -1) string += "<button class='am-btn am-btn-default am-btn-xs am-text-secondary'> 知乎</button>";
                    else string += "<button class='am-btn am-btn-default am-btn-xs am-text-secondary' disabled> 知乎</button>";
                    string += "<td>"+data.list[i].score+"</td></tr>";
                }
            }
            el.html(string)

        },
        error: function(){
            alert("nerwork error")
        }
    })
}

