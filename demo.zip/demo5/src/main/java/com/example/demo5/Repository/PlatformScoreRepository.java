package com.example.demo5.Repository;

import com.example.demo5.Entity.PlatformScore;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.Date;
import java.util.List;

public interface PlatformScoreRepository extends JpaRepository<PlatformScore,Integer> {
    public List<PlatformScore> getPlatformScoreByTimeIsAfterAndSourceIdIs(Date date, Integer id);
    public List<PlatformScore> getPlatformScoreBySourceIdIsAndUserIdIsAndTimeIsAfterOrderByTime(Integer source_id,Integer user_id, Date time);
    public List<PlatformScore> getPlatformScoreByUserIdIsAndTimeBetweenAndSourceIdIsOrderByTime(Integer user_id,Date d1,Date d2,Integer source_id);
    public List<PlatformScore> getPlatformScoreByTimeIsAfter(Date date);
}
