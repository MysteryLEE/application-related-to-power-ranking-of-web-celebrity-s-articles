package com.example.demo5.controller;

import com.alibaba.fastjson.JSON;
import com.example.demo5.Base.BaseError;
import com.example.demo5.Base.BaseJson;
import com.example.demo5.Entity.ArticleScore;
import com.example.demo5.Repository.ArticleScoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Controller
public class TestController {
    @Autowired
    private ArticleScoreRepository articleScoreRepository;
    @RequestMapping("/")
    public String requestBind(HttpServletRequest request, HttpServletResponse response){
        String data = null;
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.YEAR,-20);
        date = calendar.getTime();
        List<ArticleScore> list = new ArrayList<>();
         list = articleScoreRepository.getArticleScoreByTimeIsAfterAndSourceIdIs(date,new Integer(1));
        data = JSON.toJSONString(list);
        response.setHeader("Access-Control-Allow-Origin", "*");
        try {
            BaseJson.sendJsonData(response, data);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return  null;
    }
}
