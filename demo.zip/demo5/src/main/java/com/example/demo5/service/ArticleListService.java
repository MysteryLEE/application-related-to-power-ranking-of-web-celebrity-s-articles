package com.example.demo5.service;

import com.alibaba.fastjson.JSON;
import com.example.demo5.Base.BaseTime;
import com.example.demo5.Entity.ArticleScore;
import com.example.demo5.Repository.ArticleScoreRepository;
import com.example.demo5.bean.detail.DetailInfo;
import com.example.demo5.bean.list.Article;
import com.example.demo5.bean.list.Articles;
import com.example.demo5.bean.period.Detail;
import com.example.demo5.bean.period.Details;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ArticleListService {


    ArticleScoreRepository articleScoreRepository;

        List<ArticleScore> articleScores = new ArrayList<>();
        Articles articles = new Articles();

    public ArticleScoreRepository getArticleScoreRepository() {
        return articleScoreRepository;
    }

    public ArticleListService(ArticleScoreRepository articleScoreRepository) {
        this.articleScoreRepository = articleScoreRepository;
    }

    public Articles getArticles() {
        return articles;
    }

    public List<ArticleScore> getArticleScores() {
        return articleScores;
    }

    public void query(Integer source, Integer period){
        Date date = new Date();
        date = BaseTime.getTime(date,period);
        System.out.println(date);
        if(source!=0)
            articleScores = articleScoreRepository.getArticleScoreByTimeIsAfterAndSourceIdIs(date,source);
        else
            articleScores = articleScoreRepository.getArticleScoreByTimeIsAfter(date);
    }

    public void process(Integer source,Integer period){
        int i ,j,k;
        i = 0;
        j = articleScores.size();
        for(;i<j;){
            Integer id = articleScores.get(i).getId();
            String title = articleScores.get(i).getArticleName();
            String author = articleScores.get(i).getSourceName();
            System.out.println("//////////////////"+articleScores+"///////////////");
            int score = articleScores.get(i).getScore();
            Article article = new Article(id,title,new Date(),author,0,score);

            for(k = i+1;k<j;){
                if(articleScores.get(i).getArticleName().equals(articleScores.get(k).getArticleName())){
//                    if(article.getSource().get(article.getSource().size()-1).equals(articleScores.get(k).getSourceId()))
//                        article.setSource(articleScores.get(k).getSourceId());
                    article.score+= articleScores.get(k).getScore();
                    articleScores.remove(k);
                    j = articleScores.size();
                }else{
                    k++;
                }

            }
            articleScores.remove(i);
            j=articleScores.size();
            article.score = article.score/period;
            article.setSource(1);
            article.setSource(2);
            article.setSource(3);
            articles.add(article);

        }
    }



    public void sort(){
        for(int i = 0;i<articles.getList().size();i++){
            for(int j = 0;j<articles.getList().size()-i-1;j++){
                if(articles.getList().get(j).score<articles.getList().get(j+1).score){
                    exchange(j,articles.getList());
                }
            }
        }
        for(int i = 0;i<articles.getList().size();i++){
            articles.getList().get(i).setNo(i+1);
        }
    }


    public static void exchange(int j,List<Article> list){
        Article temp = new Article();
        temp = list.get(j);
        list.set(j,list.get(j+1));
        list.set(j+1,temp);
    }


    //以下代码用于详情页面的文章详情
    public DetailInfo queryDetail(Integer id, Integer source,Date date,Integer period){
        ArticleScore articleScore = articleScoreRepository.getArticleScoreByIdIs(id);
        String name = articleScore.getArticleName();
        System.out.println(name);
        if(articleScore==null) {

        }

        Date date1 = new Date();

        DetailInfo detailInfo = new DetailInfo();
        date = BaseTime.getTime(date,0-period);
        if(date1.after(date)) date1 = date;
        System.out.println(date1);
        if(source!=0) {
            articleScore = articleScoreRepository.getArticleScoreByArticleNameIsAndTimeIsAndSourceIdIs(name, date1, source);
            if(JSON.toJSON(articleScore)!=null){
            detailInfo.addInfo("评论数",articleScore.getComments());
            detailInfo.addInfo("转发数",articleScore.getForward());
            detailInfo.addInfo("点赞数",articleScore.getLikes());}
        }else{
            articleScore = articleScoreRepository.getArticleScoreByArticleNameIsAndTimeIsAndSourceIdIs(name, date1, 1);
            if(JSON.toJSON(articleScore)!=null){
            detailInfo.addInfo("微博评论数",articleScore.getComments());
            detailInfo.addInfo("微博转发数",articleScore.getForward());
            detailInfo.addInfo("微博点赞数",articleScore.getLikes());}
            articleScore = articleScoreRepository.getArticleScoreByArticleNameIsAndTimeIsAndSourceIdIs(name, date1, 2);
            if(JSON.toJSON(articleScore)!=null){
            detailInfo.addInfo("微信评论数",articleScore.getComments());
            detailInfo.addInfo("微信阅读量",articleScore.getForward());
            detailInfo.addInfo("微信点赞数",articleScore.getLikes());}
            articleScore = articleScoreRepository.getArticleScoreByArticleNameIsAndTimeIsAndSourceIdIs(name, date1, 3);
            if(JSON.toJSON(articleScore)!=null){
            detailInfo.addInfo("知乎评论数",articleScore.getComments());
            //detailInfo.addInfo("知乎转发数",articleScore.getForward());
            detailInfo.addInfo("知乎点赞数",articleScore.getLikes());}
        }
        return detailInfo;
    }


    //以下代码用于一段时间内的文章分数变化查询
    public Details queryPeriod(Integer id,Integer source,Date date,Integer period){
        Details details = new Details();

        ArticleScore articleScore = articleScoreRepository.getArticleScoreByIdIs(id);
        String name = articleScore.getArticleName();
        if(source!=0){
            articleScores = articleScoreRepository.getArticleScoreByArticleNameIsAndSourceIdIsAndTimeIsAfterOrderByTime(name,source,date);
            for(int i = 0;i<period&&i<articleScores.size();i++){
                ArticleScore temp = articleScores.get(i);
                details.addDetail(new Detail(temp.getDate(),temp.getScore()));
            }

        }else {
            List<ArticleScore> list1 = articleScoreRepository.getArticleScoreByArticleNameIsAndSourceIdIsAndTimeIsAfterOrderByTime(name,1,date);
            List<ArticleScore> list2 = articleScoreRepository.getArticleScoreByArticleNameIsAndSourceIdIsAndTimeIsAfterOrderByTime(name,2,date);
            List<ArticleScore> list3 = articleScoreRepository.getArticleScoreByArticleNameIsAndSourceIdIsAndTimeIsAfterOrderByTime(name,3,date);
            for(int i = 0;i<period&&i<list1.size()&&i<list2.size()&&i<list3.size();i++){
                ArticleScore temp1 = list1.get(i);
                ArticleScore temp2 = list2.get(i);
                ArticleScore temp3 = list3.get(i);
                details.addDetail(new Detail(temp1.getDate(),temp1.getScore()+temp2.getScore()+temp3.getScore()));
            }
        }
        details.setSuccess(1);
        return details;
    }
}
