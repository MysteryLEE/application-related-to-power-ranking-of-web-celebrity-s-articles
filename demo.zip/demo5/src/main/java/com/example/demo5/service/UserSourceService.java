package com.example.demo5.service;

import com.alibaba.fastjson.JSON;
import com.example.demo5.Base.BaseTime;
import com.example.demo5.Entity.ArticleScore;
import com.example.demo5.Entity.UserDetail;
import com.example.demo5.Entity.UserSource;
import com.example.demo5.Repository.ArticleScoreRepository;
import com.example.demo5.Repository.UserDetailRepository;
import com.example.demo5.Repository.UserSourceRepository;
import com.example.demo5.bean.detail.DetailInfo;

import javax.xml.bind.util.JAXBSource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserSourceService {


    UserSourceRepository userSourceRepository;
   UserSource userSource = new UserSource();
    DetailInfo detailInfo = new DetailInfo();

    public UserSourceService(UserSourceRepository userDetailRepository) {
        this.userSourceRepository = userDetailRepository;
    }
    //以下detail页面要用到的方法

    public DetailInfo queryDail(Integer id, Integer source, Date date, Integer period){
        Date date1 = new Date();




        DetailInfo detailInfo = new DetailInfo();
        date = BaseTime.getTime(date,0-period);
        if(date1.after(date)) date1 = date;
        detailInfo.setSuccess(1);

        if(source!=0) {
            userSource = userSourceRepository.getUserSourceByUserIdIsAndSignUpDateIsAndSourceIdIs(id,date1,source);
            System.out.println(date1);
            if(JSON.toJSON(userSource)!=null){
                System.out.println("查询结果不为空");
                detailInfo.addInfo("粉丝数",userSource.getFans());
                detailInfo.addInfo("文章总数",userSource.getArticles());
                detailInfo.addInfo("转发总数",userSource.getForward());
                detailInfo.addInfo("点赞总数",userSource.getLikes());}

        }else{
            userSource = userSourceRepository.getUserSourceByUserIdIsAndSignUpDateIsAndSourceIdIs(id,date1,1);
           if(JSON.toJSON(userSource)!=null){
            detailInfo.addInfo("微博粉丝数",userSource.getFans());
            detailInfo.addInfo("微博文章总数",userSource.getArticles());
            detailInfo.addInfo("微博转发总数",userSource.getForward());
            detailInfo.addInfo("微博点赞总数",userSource.getLikes());}
            userSource = userSourceRepository.getUserSourceByUserIdIsAndSignUpDateIsAndSourceIdIs(id,date1,2);
            if(JSON.toJSON(userSource)!=null){
            detailInfo.addInfo("微信粉丝数",userSource.getFans());
            detailInfo.addInfo("微信文章总数",userSource.getArticles());
            detailInfo.addInfo("微信转发总数",userSource.getForward());
            detailInfo.addInfo("微信点赞总数",userSource.getLikes());}
            userSource = userSourceRepository.getUserSourceByUserIdIsAndSignUpDateIsAndSourceIdIs(id,date1,3);
                if(JSON.toJSON(userSource)!=null){
            detailInfo.addInfo("知乎粉丝数",userSource.getFans());
            detailInfo.addInfo("知乎文章总数",userSource.getArticles());
            detailInfo.addInfo("知乎转发总数",userSource.getForward());
            detailInfo.addInfo("知乎点赞总数",userSource.getLikes());}



        }
        detailInfo.setSuccess(1);
        return detailInfo;

    }



}
