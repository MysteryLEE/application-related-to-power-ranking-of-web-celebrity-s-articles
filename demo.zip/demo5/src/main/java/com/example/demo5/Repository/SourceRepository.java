package com.example.demo5.Repository;

import com.example.demo5.Entity.Source;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SourceRepository extends JpaRepository<Source,Integer> {
}
