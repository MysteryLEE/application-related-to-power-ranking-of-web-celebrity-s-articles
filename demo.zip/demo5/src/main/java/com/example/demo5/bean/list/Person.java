package com.example.demo5.bean.list;

import java.util.ArrayList;
import java.util.List;

public class Person {
    private Integer id = -1;
    private String name = null;
    private List<Integer> source;
    private Integer no = 0;
    public Integer score = 0;

    public Person() {
    }

    public Person(Integer id, String name, Integer no, Integer score) {
        this.id = id;
        this.name = name;
        this.source = new ArrayList<>();
        this.no = no;
        this.score = score;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Integer> getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source.add(source);
    }

    public Integer getNo() {
        return no;
    }

    public void setNo(Integer no) {
        this.no = no;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }
}
