package com.example.demo5.controller;


import com.alibaba.fastjson.JSON;
import com.example.demo5.Base.BaseError;
import com.example.demo5.Base.BaseJson;
import com.example.demo5.Base.BaseSuccess;
import com.example.demo5.Base.Md5;
import com.example.demo5.Entity.User;
import com.example.demo5.Repository.UserRepository;
import com.fasterxml.jackson.databind.ser.Serializers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.NoSuchAlgorithmException;

@Controller
public class SignupController {

    @Autowired
    UserRepository userRepository;

    @RequestMapping(value = "/user/signup", method = RequestMethod.GET)
    public String signup(HttpServletRequest request, HttpServletResponse response) throws NoSuchAlgorithmException, UnsupportedEncodingException {

        BaseError error = new BaseError();
        String name = new String(request.getParameter("name"));
        String password =new String(request.getParameter("password"));



        //在此处检查参数是否有错误，然后进行下一步数据库操作
        User user = new User(name,password);
        System.out.println("存入的密码是:"+password);
        userRepository.save(user);

        //检查并存储完毕，返回success=1
        BaseSuccess success = new BaseSuccess(1);
        String data = JSON.toJSONString(success);
        response.setHeader("Access-Control-Allow-Origin", "*");
        try {
            BaseJson.sendJsonData(response, data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
