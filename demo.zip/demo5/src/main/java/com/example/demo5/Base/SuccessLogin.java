package com.example.demo5.Base;

public class SuccessLogin{
    private Integer success;
    private Integer uid;

    public SuccessLogin(Integer success, Integer uid) {
        this.success = success;
        this.uid = uid;
    }

    public Integer getSuccess() {
        return success;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }
}
