package com.example.demo5.bean.list;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Article {
    private Integer id;
    private String title;
    private Date time;
    private String author;
    private List<Integer> source;
    private Integer no;
    public double score;

    public Article() {
    }

    public Article(Integer id, String title, Date time, String author, Integer no, double score) {
        this.id = id;
        this.title = title;
        this.time = time;
        this.author = author;
        this.source = new ArrayList<>();

        this.no = no;
        this.score = score;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
       // System.out.println(sdf.format(time));
        return sdf.format(time);
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public List<Integer> getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source.add(source);
    }

    public Integer getNo() {
        return no;
    }

    public void setNo(Integer no) {
        this.no = no;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }
}
