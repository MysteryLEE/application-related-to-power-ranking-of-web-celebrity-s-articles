package com.example.demo5.Repository;

import com.example.demo5.Entity.ArticleScore;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface ArticleScoreRepository extends JpaRepository<ArticleScore,Integer> {
    public List<ArticleScore> getArticleScoreByTimeIsAfterAndSourceIdIs(Date time,Integer source_id);
    public List<ArticleScore> getArticleScoreByArticleNameIsAndSourceIdIsAndTimeIsAfterOrderByTime(String article_name,Integer source_id,Date time);
    public List<ArticleScore> getArticleScoreByArticleNameIsAndSourceIdIsAndTimeBetweenOrderByTime(String article_name,Integer source_id,Date d1,Date d2);
    public List<ArticleScore> getArticleScoreByTimeIsAfter(Date time);
    public ArticleScore getArticleScoreByIdIs(Integer id);
    public ArticleScore getArticleScoreByArticleNameIsAndTimeIsAndSourceIdIs(String name,Date time,Integer source);

}
