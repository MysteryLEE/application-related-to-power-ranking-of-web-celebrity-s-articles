package com.example.demo5.controller;

import com.alibaba.fastjson.JSON;
import com.example.demo5.Base.BaseError;
import com.example.demo5.Base.BaseJson;
import com.example.demo5.Entity.UserDetail;
import com.example.demo5.Repository.UserDetailRepository;
import com.example.demo5.bean.bind.BindInfo;
import com.example.demo5.bean.bind.SourceInfo;
import com.example.demo5.service.UserDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class BindController {
    @Autowired
    UserDetailRepository userDetailRepository;

    @RequestMapping(value = "/user/bind", method = RequestMethod.GET)
    public String requestBind(HttpServletRequest request, HttpServletResponse response){
        String data = null;

        Integer id = new Integer(request.getParameter("uid"));

        UserDetailService userDetailService = new UserDetailService(userDetailRepository);

        //此处判断传来的数据是否正确
        BindInfo bindInfo = new BindInfo();
       try{  bindInfo  = userDetailService.queryUserDetail(id);}
       catch (Exception e){
           BaseError baseError = new BaseError("查询结果集为空");
           response.setStatus(200);
           data = JSON.toJSONString(baseError);
       }

        data = JSON.toJSONString(bindInfo);

        response.setHeader("Access-Control-Allow-Origin", "*");
        try {
            BaseJson.sendJsonData(response, data);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @RequestMapping(value = "/user/bind", method = RequestMethod.POST)
    public String bind(HttpServletRequest request, HttpServletResponse response) {
        Integer id = new Integer(request.getParameter("uid"));
        Integer source = new Integer(request.getParameter("source"));
        String name = new String(request.getParameter("name"));
        UserDetailService userDetailService = new UserDetailService(userDetailRepository);
        UserDetail userDetail = userDetailRepository.getUserDetailByUserIdIs(id);
        userDetailRepository.delete(userDetail);
        if(source==1) userDetail.setMicroblogId(name);
        else if(source==2) userDetail.setWechatId(name);
        else userDetail.setZhihuId(name);
        userDetailRepository.save(userDetail);
        String data = "{"+"success"+":1}";
        response.setHeader("Access-Control-Allow-Origin", "*");
        try {
            BaseJson.sendJsonData(response, data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    return null;
    }


}
