package com.example.demo5.Base;

public class BaseSuccess {
    private Integer success;

    public BaseSuccess(Integer success) {
        this.success = success;
    }

    public Integer getSuccess() {
        return success;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }
}
