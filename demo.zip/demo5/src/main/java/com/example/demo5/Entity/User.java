package com.example.demo5.Entity;
import javax.persistence.*;

@Entity
@Table
public class User {
    @Id
    @GeneratedValue
    private Integer id;
    private String username;
    private String password;

    public User() {
       // throw new Error("Unresolved compilation problems: \n\tThe import javax.persistence cannot be resolved\n\tEntity cannot be resolved to a type\n\tTable cannot be resolved to a type\n\tId cannot be resolved to a type\n\tGeneratedValue cannot be resolved to a type\n\tGenerationType cannot be resolved to a variable\n");
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}