package com.example.demo5.bean.period;

import java.util.ArrayList;
import java.util.List;

public class Details {
    private Integer success;
    private List<Detail> list = new ArrayList<>();

    public Details() {
        //System.out.println("无参构造函数被调用");
    }

    public Details(Integer success, List<Detail> detail) {
        this.success = success;
        this.list = detail;
    }

    public Integer getSuccess() {
        return success;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public List<Detail> getDetail() {
        return list;
    }

    public void addDetail(Detail detail) {
       // System.out.println("addDetail被调用");
        this.list.add(detail);
    }
}
