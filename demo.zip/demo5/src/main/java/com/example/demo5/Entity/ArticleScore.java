package com.example.demo5.Entity;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.text.SimpleDateFormat;
import java.util.Date;

@Entity
@Table
public class ArticleScore {
    @Id
    @GeneratedValue
    private Integer id;

    @Column(name = "user_id")
    private Integer userId;

    @Column(name ="sourceId")
    private Integer sourceId;

    @Column(name ="source_name")
    private String sourceName;

    @Column(name ="article_name")
    private String articleName;

    @Column(name ="score")
    private Integer score;

    @Column(name = "time")
    @CreationTimestamp
    @Temporal(TemporalType.DATE)
    private Date time;

    @Column(name ="forward")
    private Integer forward;

    @Column(name ="likes")
    private Integer likes;

    @Column(name ="comments")
    private Integer comments;

    public ArticleScore() {
        //throw new Error("Unresolved compilation problems: \n\tThe import javax.persistence cannot be resolved\n\tEntity cannot be resolved to a type\n\tTable cannot be resolved to a type\n\tId cannot be resolved to a type\n\tGeneratedValue cannot be resolved to a type\n");
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getSourceId() {
        return sourceId;
    }

    public void setSourceId(Integer sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getArticleName() {
        return articleName;
    }

    public void setArticleName(String articleName) {
        this.articleName = articleName;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public String  getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        // System.out.println(sdf.format(time));
        return sdf.format(time);
    }
    public Date getDate(){
        return this.time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Integer getForward() {
        return forward;
    }

    public void setForward(Integer forward) {
        this.forward = forward;
    }

    public Integer getLikes() {
        return likes;
    }

    public void setLikes(Integer likes) {
        this.likes = likes;
    }

    public Integer getComments() {
        return comments;
    }

    public void setComments(Integer comments) {
        this.comments = comments;
    }
}
