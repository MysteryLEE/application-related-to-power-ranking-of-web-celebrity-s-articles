package com.example.demo5.Repository;

import com.example.demo5.Entity.UserDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserDetailRepository extends JpaRepository<com.example.demo5.Entity.UserDetail,Integer> {
    public UserDetail getUserDetailByUserIdIs(Integer id);
}
