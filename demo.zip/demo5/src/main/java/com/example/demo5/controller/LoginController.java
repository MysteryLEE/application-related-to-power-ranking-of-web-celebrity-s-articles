package com.example.demo5.controller;


import com.alibaba.fastjson.JSON;
import com.example.demo5.Base.*;
import com.example.demo5.Entity.User;
import com.example.demo5.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.NoSuchAlgorithmException;

@Controller
public class LoginController {
    @Autowired
    UserRepository userRepository;

    @RequestMapping(value = "/user/login", method = RequestMethod.POST)
    public String signup(HttpServletRequest request, HttpServletResponse response) throws NoSuchAlgorithmException, UnsupportedEncodingException {

        String data = null;
        BaseError error = new BaseError();
        String name = new String(request.getParameter("name"));

        String password = new String(request.getParameter("password"));
        User temp = userRepository.getUserByUsernameIs(name);
        //System.out.println("输入的密码是："+password);
        //System.out.println("查到的密码是："+temp.getPassword());
        if(temp.getPassword().equals(password)) {
            SuccessLogin success = new SuccessLogin(1,temp.getId());
            data = JSON.toJSONString(success);
        }else {
            BaseSuccess success = new BaseSuccess(0);
            data = JSON.toJSONString(success);
        }
        response.setHeader("Access-Control-Allow-Origin", "*");
        try {
            BaseJson.sendJsonData(response, data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    return  null;
    }
}
