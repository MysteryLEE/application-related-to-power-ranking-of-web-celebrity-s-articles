package com.example.demo5.bean.bind;

public class SourceInfo {
    private Integer source;
    private String name;

    public SourceInfo() {
    }

    public SourceInfo(Integer source, String name) {
        this.source = source;
        this.name = name;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
