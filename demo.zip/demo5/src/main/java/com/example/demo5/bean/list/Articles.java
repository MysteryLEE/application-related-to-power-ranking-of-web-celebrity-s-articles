package com.example.demo5.bean.list;

import java.util.ArrayList;
import java.util.List;

public class Articles {
    private Integer success =1;
    private List<Article> list = new ArrayList<>();

    public Articles() {
    }

    public Articles(Integer success, List<Article> list) {
        this.success = success;
        this.list = list;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public void add(Article article){
        this.list.add(article);
    }

    public Integer getSuccess() {
        return success;
    }

    public List<Article> getList() {
        return list;
    }
}
