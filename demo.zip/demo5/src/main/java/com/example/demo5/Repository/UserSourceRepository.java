package com.example.demo5.Repository;

import com.example.demo5.Entity.User;
import com.example.demo5.Entity.UserDetail;
import com.example.demo5.Entity.UserSource;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface UserSourceRepository extends JpaRepository<UserSource,Integer> {
    public UserSource getUserSourceByUserIdIsAndSignUpDateIsAndSourceIdIs(Integer id, Date date,Integer source);
}
