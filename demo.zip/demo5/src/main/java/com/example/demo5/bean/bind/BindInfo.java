package com.example.demo5.bean.bind;

import java.util.ArrayList;
import java.util.List;

public class BindInfo {
    private Integer success;
    private List<SourceInfo> detail = new ArrayList<>();

    public BindInfo() {
    }

    public Integer getSuccess() {
        return success;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public List<SourceInfo> getDetail() {
        return detail;
    }


    public void addDetail(SourceInfo detail) {
        this.detail.add(detail);
    }

    public BindInfo(Integer success, List<SourceInfo> detail) {
        this.success = success;
        this.detail = detail;
    }
}
