package com.example.demo5.bean.period;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Detail {
    Date time;
    double score;

    public Detail() {
    }

    public Detail(Date time, double score) {
        this.time = time;
        this.score = score;
    }

    public String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(time);
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public double getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }
}
