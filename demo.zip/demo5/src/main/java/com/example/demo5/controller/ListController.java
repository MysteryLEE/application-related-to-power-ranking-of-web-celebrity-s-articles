package com.example.demo5.controller;



import com.alibaba.fastjson.JSON;
import com.example.demo5.Base.BaseJson;
import com.example.demo5.Repository.ArticleScoreRepository;
import com.example.demo5.Repository.PlatformScoreRepository;
import com.example.demo5.bean.list.Article;
import com.example.demo5.bean.list.Articles;
import com.example.demo5.bean.list.People;
import com.example.demo5.bean.list.Person;
import com.example.demo5.Base.BaseError;
import com.example.demo5.service.ArticleListService;
import com.example.demo5.service.PersonListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
public class ListController {
    @Autowired
    ArticleScoreRepository articleScoreRepository;


    @Autowired
    PlatformScoreRepository platformScoreRepository;
    @RequestMapping(value = "/info/list",method = RequestMethod.GET)
    public String test(HttpServletRequest request,HttpServletResponse response){
        Integer tag = new Integer(request.getParameter("tag"));
        Integer type = new Integer(request.getParameter("type"));
        Integer size = new Integer(request.getParameter("size"));
        Integer period = new Integer(request.getParameter("period"));



            String data = null;

         if (type == 1) {

                //判断要获取的人的来源，然后计算得分，填写数据
                PersonListService personListService = new PersonListService(platformScoreRepository);
                personListService.query(tag,period);
                if(personListService.getPlatformScores()==null){
                    BaseError error = new BaseError("查询结果为空");
                    data = JSON.toJSONString(error);
                }
                else {
                    personListService.process(tag, period);
                    personListService.sort();
                    data = JSON.toJSONString(personListService.getPeople());
                }
            } else {

                //判断要获取的文章的来源，然后计算得分，填写数据
                ArticleListService articleListService = new ArticleListService(articleScoreRepository);
                articleListService.query(tag,period);
                if(null==articleListService.getArticleScores()){
                    BaseError error = new BaseError("查询结果为空");
                    data = JSON.toJSONString(error);
                }
                else {
                    articleListService.process(tag, period);
                    articleListService.sort();
                    data = JSON.toJSONString(articleListService.getArticles());
                }
            }
        response.setHeader("Access-Control-Allow-Origin", "*");
            try {
                BaseJson.sendJsonData(response, data);
            } catch (Exception e) {
                e.printStackTrace();
            }

        return null;
    }


}
