package com.example.demo5.controller;

import com.alibaba.fastjson.JSON;
import com.example.demo5.Base.BaseError;
import com.example.demo5.Base.BaseJson;
import com.example.demo5.Repository.ArticleScoreRepository;
import com.example.demo5.Repository.UserSourceRepository;
import com.example.demo5.bean.detail.DetailInfo;
import com.example.demo5.service.ArticleListService;
import com.example.demo5.service.UserSourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

@Controller
public class ListDetailController {
    @Autowired
    UserSourceRepository userSourceRepository;

    @Autowired
    ArticleScoreRepository articleScoreRepository;


    @RequestMapping(value = "/info/detail",method = RequestMethod.GET)
    public String ListDetail(HttpServletRequest request, HttpServletResponse response){
        BaseError error = new BaseError();

        //get请求中有tag, type, id, period, time
        Integer tag = new Integer(request.getParameter("tag"));
        Integer type = new Integer(request.getParameter("type"));
        Integer id = new Integer(request.getParameter("id"));
        Integer period = new Integer(request.getParameter("period"));
        String[] date = new String(request.getParameter("time")).split("-");
        Integer year = Integer.parseInt(date[0]);
        Integer month = Integer.parseInt(date[1]);
        Integer day = Integer.parseInt(date[2]);
        Date time = new Date(year-1900,month-1,day);
        String data = null;

        if(type == 1){

            //判断要获取的人的来源，获取具体信息，然后填入返回类
            UserSourceService userSourceService = new UserSourceService(userSourceRepository);

            DetailInfo detailInfo = userSourceService.queryDail(id,tag,time,period);
            if (!JSON.toJSONString(detailInfo.getDetail()).equals("[]")) {
                System.out.println(JSON.toJSONString(detailInfo.getDetail())+"qewrqwerqwer");
                data = JSON.toJSONString(detailInfo);
            }
            else{
                data = JSON.toJSONString(new BaseError("数据库没有对应信息"));
            }
            System.out.println(data);
        }
        else {
            //判断要获取的文章的来源，获取具体信息，然后填入返回类
            ArticleListService articleListService = new ArticleListService(articleScoreRepository);
            DetailInfo detailInfo = articleListService.queryDetail(id,tag,time,period);
            if(!JSON.toJSONString(detailInfo.getDetail()).equals("[]"))
            data = JSON.toJSONString(detailInfo);
            else{
                data = JSON.toJSONString(new BaseError("数据库没有对应信息"));
            }
        }
        response.setHeader("Access-Control-Allow-Origin", "*");
        try {
            BaseJson.sendJsonData(response, data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
