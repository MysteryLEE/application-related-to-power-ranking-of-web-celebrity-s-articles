package com.example.demo5.service;

import com.example.demo5.Entity.User;
import com.example.demo5.Entity.UserDetail;
import com.example.demo5.Repository.UserDetailRepository;
import com.example.demo5.bean.bind.BindInfo;
import com.example.demo5.bean.bind.SourceInfo;

public class UserDetailService {

    UserDetailRepository userDetailRepository;

    public UserDetailService(UserDetailRepository userDetailRepository) {
        this.userDetailRepository = userDetailRepository;
    }

    //以下函数用于用户绑定信息的获取
    public BindInfo queryUserDetail(Integer uid){

        UserDetail user = userDetailRepository.getUserDetailByUserIdIs(uid);
        BindInfo bindInfo = new BindInfo();
        bindInfo.setSuccess(1);
        bindInfo.addDetail(new SourceInfo(1,user.getMicroblogId()));
        bindInfo.addDetail(new SourceInfo(2,user.getWechatId()));
        bindInfo.addDetail(new SourceInfo(3,user.getZhihuId()));
        return bindInfo;
    }
}
