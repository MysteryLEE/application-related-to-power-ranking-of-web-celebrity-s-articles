package com.example.demo5.Entity;

import javax.persistence.*;

@Entity
@Table
public class Source {
    @Id
    @GeneratedValue
    private Integer id;

    @Column(name = "source_name")
    private String sourceName;

    public Source() {
//        throw new Error("Unresolved compilation problems: \n\tThe import javax.persistence cannot be resolved\n\tEntity cannot be resolved to a type\n\tTable cannot be resolved to a type\n\tId cannot be resolved to a type\n\tGeneratedValue cannot be resolved to a type\n");
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }
}

