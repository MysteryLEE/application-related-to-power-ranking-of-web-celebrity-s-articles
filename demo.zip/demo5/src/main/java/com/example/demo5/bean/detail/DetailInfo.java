package com.example.demo5.bean.detail;

import com.fasterxml.jackson.databind.ser.Serializers;

import java.util.ArrayList;
import java.util.List;

public class DetailInfo {
    private Integer success;
    private Integer id;

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public void setScore(double score) {
        this.score = score;
    }

    private double score=-1;
    private List<BaseInfo> detail = new ArrayList<>();

    public DetailInfo() {
    }

    public DetailInfo(Integer id, List<BaseInfo> list) {
        this.id = id;
        this.detail = list;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void addInfo(String name,double score ){
        this.detail.add(new BaseInfo(name,score));
    }

    public Integer getId() {
        return id;
    }

    public List<BaseInfo> getDetail() {
        return detail;
    }
}
