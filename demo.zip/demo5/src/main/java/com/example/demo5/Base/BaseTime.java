package com.example.demo5.Base;

import java.util.Calendar;
import java.util.Date;

public class BaseTime {
    public static Date getTime(Date date,Integer period){

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE,0-period);
        date = calendar.getTime();
        return date;
    }
}
