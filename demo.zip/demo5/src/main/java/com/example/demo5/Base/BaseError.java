package com.example.demo5.Base;

public class BaseError {

    private String err_msg;
    private Integer success = 0;

    public Integer getSuccess() {
        return success;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public BaseError() {

        this.err_msg = "";
    }

    public BaseError( String err_msg) {

        this.err_msg = err_msg;
    }





    public String getErr_msg() {
        return err_msg;
    }

    public void setErr_msg(String err_msg) {
        this.err_msg = this.err_msg + err_msg+"    ";
    }
}
