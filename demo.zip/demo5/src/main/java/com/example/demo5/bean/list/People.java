package com.example.demo5.bean.list;

import java.util.ArrayList;
import java.util.List;

public class People {
    private Integer success=1;
    private List<Person> list = new ArrayList<>();

    public People() {
    }

    public People(Integer success, List<Person> personList) {
        this.success = success;
        this.list = personList;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public void add(Person person){
        this.list.add(person);
    }

    public Integer getSuccess() {
        return success;
    }

    public List<Person> getList() {
        return list;
    }
}
