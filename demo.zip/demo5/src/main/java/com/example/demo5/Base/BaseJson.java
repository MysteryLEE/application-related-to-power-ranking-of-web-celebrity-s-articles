package com.example.demo5.Base;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

public class BaseJson {
    public static void sendJsonData(HttpServletResponse response, String data)
            throws Exception
    {
        response.setContentType("text/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println(data);
        out.flush();
        out.close();
    }
}
