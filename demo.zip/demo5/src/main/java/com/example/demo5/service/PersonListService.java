package com.example.demo5.service;

import com.example.demo5.Base.BaseTime;
import com.example.demo5.Entity.PlatformScore;
import com.example.demo5.Repository.PlatformScoreRepository;
import com.example.demo5.bean.detail.DetailInfo;
import com.example.demo5.bean.list.People;
import com.example.demo5.bean.list.Person;
import com.example.demo5.bean.period.Detail;
import com.example.demo5.bean.period.Details;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PersonListService {
    PlatformScoreRepository platformScoreRepository;
    List<PlatformScore> platformScores = new ArrayList<>();
    People people = new People();

    public PlatformScoreRepository getPlatformScoreRepository() {
        return platformScoreRepository;
    }

    public PersonListService(PlatformScoreRepository platformScoreRepository) {
        this.platformScoreRepository = platformScoreRepository;
    }

    public List<PlatformScore> getPlatformScores() {
        return platformScores;
    }

    public People getPeople() {
        return people;
    }

    //以下是list页面要用到的方法
    public void query(Integer source, Integer period){
        platformScores = null;
        Date date = new Date();
        date = BaseTime.getTime(date,period+1);
        System.out.println(date+"//////////////345243523452435////////////////////////////");
        if(source!=0)
            platformScores = platformScoreRepository.getPlatformScoreByTimeIsAfterAndSourceIdIs(date,source);
        else
            platformScores = platformScoreRepository.getPlatformScoreByTimeIsAfter(date);
    }

    public void process(Integer source,Integer period){
        int i ,j,k;
        i = 0;
        j = platformScores.size();
        for(;i<j;){
            Integer id = platformScores.get(i).getUserId();
            String name = platformScores.get(i).getSourceName();

            int score = platformScores.get(i).getScore();
            Person person = new Person(id,name,0,score);

            for(k = i+1;k<j;){
                if(platformScores.get(i).getSourceName().equals(platformScores.get(k).getSourceName())){
//                    if(person.getSource().get(person.getSource().size()-1).equals(platformScores.get(k).getSourceId()))
//                        person.setSource(platformScores.get(k).getSourceId());

                    person.score+= platformScores.get(k).getScore();
                    platformScores.remove(k);
                    j = platformScores.size();
                }else{
                    k++;
                }
            }
            platformScores.remove(i);
            j=platformScores.size();
            person.setSource(1);
            person.setSource(2);
            person.setSource(3);
            person.score = person.score/period;
            people.add(person);

        }
    }

    public void sort(){
        for(int i = 0;i<people.getList().size();i++){
            for(int j = 0;j<people.getList().size()-i-1;j++){
                if(people.getList().get(j).score<people.getList().get(j+1).score){
                    exchange(j,people.getList());
                }
            }
        }
        for(int i = 0;i<people.getList().size();i++){
            people.getList().get(i).setNo(i+1);
        }
    }


    public static void exchange(int j,List<Person> list){
        Person temp = new Person();
        temp = list.get(j);
        list.set(j,list.get(j+1));
        list.set(j+1,temp);
    }

    //以下函数用于用户在某平台一段时间内的得分情况
    public Details queryPeriod(Integer id,Integer source, Date date,Integer period){
        Details details = new Details();
        if(source!=0){
            platformScores = platformScoreRepository.getPlatformScoreBySourceIdIsAndUserIdIsAndTimeIsAfterOrderByTime(source,id,date);
            for(int i = 0;i<period&&i<platformScores.size();i++){
                PlatformScore temp = platformScores.get(i);
                details.addDetail(new Detail(temp.getTime(),temp.getScore()));
            }

        }else {
            List<PlatformScore> list1 = platformScoreRepository.getPlatformScoreBySourceIdIsAndUserIdIsAndTimeIsAfterOrderByTime(1,id,date);
            List<PlatformScore> list2 = platformScoreRepository.getPlatformScoreBySourceIdIsAndUserIdIsAndTimeIsAfterOrderByTime(2,id,date);
            List<PlatformScore> list3 = platformScoreRepository.getPlatformScoreBySourceIdIsAndUserIdIsAndTimeIsAfterOrderByTime(3,id,date);
            for(int i = 0;i<period&&i<list1.size()&&i<list2.size()&&i<list3.size();i++){
                PlatformScore temp1 = list1.get(i);
                PlatformScore temp2 = list2.get(i);
                PlatformScore temp3 = list3.get(i);
                details.addDetail(new Detail(temp1.getTime(),temp1.getScore()+temp2.getScore()+temp3.getScore()));
            }
        }
        details.setSuccess(1);
        return details;

    }
}
